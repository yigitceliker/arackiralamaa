﻿namespace AracKiralamaOtomasyonu
{
    partial class OtomasyonForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.DtpTeslimAlınacak = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbTutar = new System.Windows.Forms.TextBox();
            this.DtpTeslimEdilecek = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DgwKiralamaAraclar = new System.Windows.Forms.DataGridView();
            this.DgwKiralamaMusteriler = new System.Windows.Forms.DataGridView();
            this.btIslemiOnayla = new System.Windows.Forms.Button();
            this.Tab2 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.buttonislemTamamlandı = new System.Windows.Forms.Button();
            this.buttonAktifiptal = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.DtpAiTeslimEdilecek = new System.Windows.Forms.DateTimePicker();
            this.DtpAiTeslimAlınacak = new System.Windows.Forms.DateTimePicker();
            this.buttonAiGuncelle = new System.Windows.Forms.Button();
            this.tbAktifTutar = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.DgwAktifislemler = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.buttonKaydiSil = new System.Windows.Forms.Button();
            this.DgwGecmisislemler = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.ButtonPlakayaGoreSil = new System.Windows.Forms.Button();
            this.tbSilPlaka = new System.Windows.Forms.TextBox();
            this.ButtonAraciSil = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonAracGuncelle = new System.Windows.Forms.Button();
            this.tbGuncelleKm = new System.Windows.Forms.TextBox();
            this.tbGuncelleGunlukFiyat = new System.Windows.Forms.TextBox();
            this.tbGuncelleYili = new System.Windows.Forms.TextBox();
            this.tbGuncelleRenk = new System.Windows.Forms.TextBox();
            this.tbGuncelleModel = new System.Windows.Forms.TextBox();
            this.tbGuncelleMarka = new System.Windows.Forms.TextBox();
            this.tbGuncellePlaka = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonAracEkle = new System.Windows.Forms.Button();
            this.tbEkleKm = new System.Windows.Forms.TextBox();
            this.tbEkleGunlukFiyat = new System.Windows.Forms.TextBox();
            this.tbEkleYili = new System.Windows.Forms.TextBox();
            this.tbEkleRenk = new System.Windows.Forms.TextBox();
            this.tbEkleModel = new System.Windows.Forms.TextBox();
            this.tbEkleMarka = new System.Windows.Forms.TextBox();
            this.tbEklePlaka = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.DgwAraclar = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.buttonMusteriSil = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.buttonGuncelleMusteri = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.tbGuncelleTelefon = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.tbGuncelleAdres = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.tbGuncelleSoyad = new System.Windows.Forms.TextBox();
            this.tbGuncelleAd = new System.Windows.Forms.TextBox();
            this.tbGuncelleTcKimlik = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.buttonMusteriEkle = new System.Windows.Forms.Button();
            this.tbEkleTelefon = new System.Windows.Forms.TextBox();
            this.tbEkleAdres = new System.Windows.Forms.TextBox();
            this.tbEkleSoyad = new System.Windows.Forms.TextBox();
            this.tbEkleAd = new System.Windows.Forms.TextBox();
            this.tbEkleTcKimlik = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.DgwMusteriler = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwKiralamaAraclar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgwKiralamaMusteriler)).BeginInit();
            this.Tab2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwAktifislemler)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwGecmisislemler)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwAraclar)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwMusteriler)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.Tab2);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(917, 602);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.DtpTeslimAlınacak);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.tbTutar);
            this.tabPage1.Controls.Add(this.DtpTeslimEdilecek);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.DgwKiralamaAraclar);
            this.tabPage1.Controls.Add(this.DgwKiralamaMusteriler);
            this.tabPage1.Controls.Add(this.btIslemiOnayla);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(909, 576);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Kiralama İşlemleri";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // DtpTeslimAlınacak
            // 
            this.DtpTeslimAlınacak.Location = new System.Drawing.Point(22, 503);
            this.DtpTeslimAlınacak.MinDate = new System.DateTime(2015, 5, 13, 0, 0, 0, 0);
            this.DtpTeslimAlınacak.Name = "DtpTeslimAlınacak";
            this.DtpTeslimAlınacak.Size = new System.Drawing.Size(200, 20);
            this.DtpTeslimAlınacak.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(19, 476);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(92, 13);
            this.label20.TabIndex = 10;
            this.label20.Text = "Teslim Alınan Gün";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(452, 476);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Tutar :";
            // 
            // tbTutar
            // 
            this.tbTutar.Location = new System.Drawing.Point(455, 503);
            this.tbTutar.Name = "tbTutar";
            this.tbTutar.Size = new System.Drawing.Size(95, 20);
            this.tbTutar.TabIndex = 8;
            // 
            // DtpTeslimEdilecek
            // 
            this.DtpTeslimEdilecek.Location = new System.Drawing.Point(228, 503);
            this.DtpTeslimEdilecek.Name = "DtpTeslimEdilecek";
            this.DtpTeslimEdilecek.Size = new System.Drawing.Size(200, 20);
            this.DtpTeslimEdilecek.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(225, 476);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Teslim Edileceği Gün";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Müsait Araçlar :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Müşteriler :";
            // 
            // DgwKiralamaAraclar
            // 
            this.DgwKiralamaAraclar.AllowUserToAddRows = false;
            this.DgwKiralamaAraclar.AllowUserToDeleteRows = false;
            this.DgwKiralamaAraclar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgwKiralamaAraclar.Location = new System.Drawing.Point(22, 257);
            this.DgwKiralamaAraclar.MultiSelect = false;
            this.DgwKiralamaAraclar.Name = "DgwKiralamaAraclar";
            this.DgwKiralamaAraclar.ReadOnly = true;
            this.DgwKiralamaAraclar.Size = new System.Drawing.Size(796, 198);
            this.DgwKiralamaAraclar.TabIndex = 2;
            // 
            // DgwKiralamaMusteriler
            // 
            this.DgwKiralamaMusteriler.AllowUserToAddRows = false;
            this.DgwKiralamaMusteriler.AllowUserToDeleteRows = false;
            this.DgwKiralamaMusteriler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgwKiralamaMusteriler.Location = new System.Drawing.Point(22, 32);
            this.DgwKiralamaMusteriler.MultiSelect = false;
            this.DgwKiralamaMusteriler.Name = "DgwKiralamaMusteriler";
            this.DgwKiralamaMusteriler.ReadOnly = true;
            this.DgwKiralamaMusteriler.Size = new System.Drawing.Size(796, 198);
            this.DgwKiralamaMusteriler.TabIndex = 1;
            // 
            // btIslemiOnayla
            // 
            this.btIslemiOnayla.Location = new System.Drawing.Point(580, 500);
            this.btIslemiOnayla.Name = "btIslemiOnayla";
            this.btIslemiOnayla.Size = new System.Drawing.Size(107, 23);
            this.btIslemiOnayla.TabIndex = 0;
            this.btIslemiOnayla.Text = "İşlemi Onayla";
            this.btIslemiOnayla.UseVisualStyleBackColor = true;
            this.btIslemiOnayla.Click += new System.EventHandler(this.btIslemiOnayla_Click);
            // 
            // Tab2
            // 
            this.Tab2.Controls.Add(this.groupBox7);
            this.Tab2.Controls.Add(this.groupBox8);
            this.Tab2.Controls.Add(this.DgwAktifislemler);
            this.Tab2.Location = new System.Drawing.Point(4, 22);
            this.Tab2.Name = "Tab2";
            this.Tab2.Size = new System.Drawing.Size(909, 576);
            this.Tab2.TabIndex = 3;
            this.Tab2.Text = "Aktif İşlemler";
            this.Tab2.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.buttonislemTamamlandı);
            this.groupBox7.Controls.Add(this.buttonAktifiptal);
            this.groupBox7.Location = new System.Drawing.Point(306, 330);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(288, 242);
            this.groupBox7.TabIndex = 21;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "İşlemler";
            // 
            // buttonislemTamamlandı
            // 
            this.buttonislemTamamlandı.Location = new System.Drawing.Point(23, 121);
            this.buttonislemTamamlandı.Name = "buttonislemTamamlandı";
            this.buttonislemTamamlandı.Size = new System.Drawing.Size(239, 23);
            this.buttonislemTamamlandı.TabIndex = 19;
            this.buttonislemTamamlandı.Text = "İşlem Tamamlandı";
            this.buttonislemTamamlandı.UseVisualStyleBackColor = true;
            this.buttonislemTamamlandı.Click += new System.EventHandler(this.buttonislemTamamlandı_Click);
            // 
            // buttonAktifiptal
            // 
            this.buttonAktifiptal.Location = new System.Drawing.Point(23, 81);
            this.buttonAktifiptal.Name = "buttonAktifiptal";
            this.buttonAktifiptal.Size = new System.Drawing.Size(239, 23);
            this.buttonAktifiptal.TabIndex = 17;
            this.buttonAktifiptal.Text = "İşlemi İptal Et";
            this.buttonAktifiptal.UseVisualStyleBackColor = true;
            this.buttonAktifiptal.Click += new System.EventHandler(this.buttonAktifiptal_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.DtpAiTeslimEdilecek);
            this.groupBox8.Controls.Add(this.DtpAiTeslimAlınacak);
            this.groupBox8.Controls.Add(this.buttonAiGuncelle);
            this.groupBox8.Controls.Add(this.tbAktifTutar);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Controls.Add(this.label38);
            this.groupBox8.Location = new System.Drawing.Point(3, 330);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(288, 242);
            this.groupBox8.TabIndex = 20;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Güncelleme İşlemleri";
            // 
            // DtpAiTeslimEdilecek
            // 
            this.DtpAiTeslimEdilecek.Location = new System.Drawing.Point(76, 90);
            this.DtpAiTeslimEdilecek.Name = "DtpAiTeslimEdilecek";
            this.DtpAiTeslimEdilecek.Size = new System.Drawing.Size(193, 20);
            this.DtpAiTeslimEdilecek.TabIndex = 19;
            // 
            // DtpAiTeslimAlınacak
            // 
            this.DtpAiTeslimAlınacak.Location = new System.Drawing.Point(76, 60);
            this.DtpAiTeslimAlınacak.Name = "DtpAiTeslimAlınacak";
            this.DtpAiTeslimAlınacak.Size = new System.Drawing.Size(193, 20);
            this.DtpAiTeslimAlınacak.TabIndex = 18;
            // 
            // buttonAiGuncelle
            // 
            this.buttonAiGuncelle.Location = new System.Drawing.Point(76, 213);
            this.buttonAiGuncelle.Name = "buttonAiGuncelle";
            this.buttonAiGuncelle.Size = new System.Drawing.Size(137, 23);
            this.buttonAiGuncelle.TabIndex = 17;
            this.buttonAiGuncelle.Text = "Güncelle";
            this.buttonAiGuncelle.UseVisualStyleBackColor = true;
            this.buttonAiGuncelle.Click += new System.EventHandler(this.buttonAiGuncelle_Click);
            // 
            // tbAktifTutar
            // 
            this.tbAktifTutar.Location = new System.Drawing.Point(76, 31);
            this.tbAktifTutar.Name = "tbAktifTutar";
            this.tbAktifTutar.Size = new System.Drawing.Size(193, 20);
            this.tbAktifTutar.TabIndex = 10;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(12, 34);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(38, 13);
            this.label24.TabIndex = 4;
            this.label24.Text = "Tutar :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(0, 90);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(72, 13);
            this.label27.TabIndex = 6;
            this.label27.Text = "Teslim Tarihi :";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(9, 60);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(61, 13);
            this.label38.TabIndex = 7;
            this.label38.Text = "Alım Tarihi :";
            // 
            // DgwAktifislemler
            // 
            this.DgwAktifislemler.AllowUserToAddRows = false;
            this.DgwAktifislemler.AllowUserToDeleteRows = false;
            this.DgwAktifislemler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgwAktifislemler.Location = new System.Drawing.Point(3, 3);
            this.DgwAktifislemler.MultiSelect = false;
            this.DgwAktifislemler.Name = "DgwAktifislemler";
            this.DgwAktifislemler.ReadOnly = true;
            this.DgwAktifislemler.Size = new System.Drawing.Size(901, 321);
            this.DgwAktifislemler.TabIndex = 2;
            this.DgwAktifislemler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgwAktifislemler_CellClick);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.DgwGecmisislemler);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(909, 576);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Kiralama Geçmişi";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.buttonKaydiSil);
            this.groupBox9.Location = new System.Drawing.Point(4, 334);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(288, 242);
            this.groupBox9.TabIndex = 24;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "İşlemler";
            // 
            // buttonKaydiSil
            // 
            this.buttonKaydiSil.Location = new System.Drawing.Point(23, 121);
            this.buttonKaydiSil.Name = "buttonKaydiSil";
            this.buttonKaydiSil.Size = new System.Drawing.Size(239, 23);
            this.buttonKaydiSil.TabIndex = 19;
            this.buttonKaydiSil.Text = "Kaydı Sil";
            this.buttonKaydiSil.UseVisualStyleBackColor = true;
            this.buttonKaydiSil.Click += new System.EventHandler(this.buttonKaydiSil_Click);
            // 
            // DgwGecmisislemler
            // 
            this.DgwGecmisislemler.AllowUserToAddRows = false;
            this.DgwGecmisislemler.AllowUserToDeleteRows = false;
            this.DgwGecmisislemler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgwGecmisislemler.Location = new System.Drawing.Point(4, 4);
            this.DgwGecmisislemler.MultiSelect = false;
            this.DgwGecmisislemler.Name = "DgwGecmisislemler";
            this.DgwGecmisislemler.ReadOnly = true;
            this.DgwGecmisislemler.Size = new System.Drawing.Size(901, 321);
            this.DgwGecmisislemler.TabIndex = 22;
            this.DgwGecmisislemler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgwGecmisislemler_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.DgwAraclar);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(909, 576);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Araçlar";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.ButtonPlakayaGoreSil);
            this.groupBox3.Controls.Add(this.tbSilPlaka);
            this.groupBox3.Controls.Add(this.ButtonAraciSil);
            this.groupBox3.Location = new System.Drawing.Point(614, 328);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(288, 242);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Silme İşlemleri";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(19, 124);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 13);
            this.label19.TabIndex = 20;
            this.label19.Text = "Plaka :";
            // 
            // ButtonPlakayaGoreSil
            // 
            this.ButtonPlakayaGoreSil.Location = new System.Drawing.Point(22, 164);
            this.ButtonPlakayaGoreSil.Name = "ButtonPlakayaGoreSil";
            this.ButtonPlakayaGoreSil.Size = new System.Drawing.Size(239, 23);
            this.ButtonPlakayaGoreSil.TabIndex = 19;
            this.ButtonPlakayaGoreSil.Text = "Sil";
            this.ButtonPlakayaGoreSil.UseVisualStyleBackColor = true;
            this.ButtonPlakayaGoreSil.Click += new System.EventHandler(this.ButtonPlakayaGoreSil_Click);
            // 
            // tbSilPlaka
            // 
            this.tbSilPlaka.Location = new System.Drawing.Point(79, 121);
            this.tbSilPlaka.Name = "tbSilPlaka";
            this.tbSilPlaka.Size = new System.Drawing.Size(182, 20);
            this.tbSilPlaka.TabIndex = 18;
            // 
            // ButtonAraciSil
            // 
            this.ButtonAraciSil.Location = new System.Drawing.Point(22, 50);
            this.ButtonAraciSil.Name = "ButtonAraciSil";
            this.ButtonAraciSil.Size = new System.Drawing.Size(239, 23);
            this.ButtonAraciSil.TabIndex = 17;
            this.ButtonAraciSil.Text = "Seçileni Sil";
            this.ButtonAraciSil.UseVisualStyleBackColor = true;
            this.ButtonAraciSil.Click += new System.EventHandler(this.ButtonAraciSil_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonAracGuncelle);
            this.groupBox2.Controls.Add(this.tbGuncelleKm);
            this.groupBox2.Controls.Add(this.tbGuncelleGunlukFiyat);
            this.groupBox2.Controls.Add(this.tbGuncelleYili);
            this.groupBox2.Controls.Add(this.tbGuncelleRenk);
            this.groupBox2.Controls.Add(this.tbGuncelleModel);
            this.groupBox2.Controls.Add(this.tbGuncelleMarka);
            this.groupBox2.Controls.Add(this.tbGuncellePlaka);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Location = new System.Drawing.Point(311, 328);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(288, 242);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Güncelleme İşlemleri";
            // 
            // buttonAracGuncelle
            // 
            this.buttonAracGuncelle.Location = new System.Drawing.Point(76, 213);
            this.buttonAracGuncelle.Name = "buttonAracGuncelle";
            this.buttonAracGuncelle.Size = new System.Drawing.Size(137, 23);
            this.buttonAracGuncelle.TabIndex = 17;
            this.buttonAracGuncelle.Text = "Güncelle";
            this.buttonAracGuncelle.UseVisualStyleBackColor = true;
            this.buttonAracGuncelle.Click += new System.EventHandler(this.buttonAracGuncelle_Click);
            // 
            // tbGuncelleKm
            // 
            this.tbGuncelleKm.Location = new System.Drawing.Point(76, 184);
            this.tbGuncelleKm.Name = "tbGuncelleKm";
            this.tbGuncelleKm.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleKm.TabIndex = 16;
            // 
            // tbGuncelleGunlukFiyat
            // 
            this.tbGuncelleGunlukFiyat.Location = new System.Drawing.Point(76, 158);
            this.tbGuncelleGunlukFiyat.Name = "tbGuncelleGunlukFiyat";
            this.tbGuncelleGunlukFiyat.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleGunlukFiyat.TabIndex = 15;
            // 
            // tbGuncelleYili
            // 
            this.tbGuncelleYili.Location = new System.Drawing.Point(76, 132);
            this.tbGuncelleYili.Name = "tbGuncelleYili";
            this.tbGuncelleYili.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleYili.TabIndex = 14;
            // 
            // tbGuncelleRenk
            // 
            this.tbGuncelleRenk.Location = new System.Drawing.Point(76, 109);
            this.tbGuncelleRenk.Name = "tbGuncelleRenk";
            this.tbGuncelleRenk.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleRenk.TabIndex = 13;
            // 
            // tbGuncelleModel
            // 
            this.tbGuncelleModel.Location = new System.Drawing.Point(76, 83);
            this.tbGuncelleModel.Name = "tbGuncelleModel";
            this.tbGuncelleModel.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleModel.TabIndex = 12;
            // 
            // tbGuncelleMarka
            // 
            this.tbGuncelleMarka.Location = new System.Drawing.Point(76, 57);
            this.tbGuncelleMarka.Name = "tbGuncelleMarka";
            this.tbGuncelleMarka.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleMarka.TabIndex = 11;
            // 
            // tbGuncellePlaka
            // 
            this.tbGuncellePlaka.Location = new System.Drawing.Point(76, 31);
            this.tbGuncellePlaka.Name = "tbGuncellePlaka";
            this.tbGuncellePlaka.Size = new System.Drawing.Size(137, 20);
            this.tbGuncellePlaka.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Renk :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 34);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Plaka :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 187);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Km :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 90);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 13);
            this.label15.TabIndex = 6;
            this.label15.Text = "Model :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 162);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "Günlük Fiyat :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(18, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Yılı :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(9, 60);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Marka :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonAracEkle);
            this.groupBox1.Controls.Add(this.tbEkleKm);
            this.groupBox1.Controls.Add(this.tbEkleGunlukFiyat);
            this.groupBox1.Controls.Add(this.tbEkleYili);
            this.groupBox1.Controls.Add(this.tbEkleRenk);
            this.groupBox1.Controls.Add(this.tbEkleModel);
            this.groupBox1.Controls.Add(this.tbEkleMarka);
            this.groupBox1.Controls.Add(this.tbEklePlaka);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Location = new System.Drawing.Point(6, 328);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 242);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ekleme İşlemleri";
            // 
            // buttonAracEkle
            // 
            this.buttonAracEkle.Location = new System.Drawing.Point(76, 213);
            this.buttonAracEkle.Name = "buttonAracEkle";
            this.buttonAracEkle.Size = new System.Drawing.Size(137, 23);
            this.buttonAracEkle.TabIndex = 17;
            this.buttonAracEkle.Text = "Ekle";
            this.buttonAracEkle.UseVisualStyleBackColor = true;
            this.buttonAracEkle.Click += new System.EventHandler(this.buttonAracEkle_Click);
            // 
            // tbEkleKm
            // 
            this.tbEkleKm.Location = new System.Drawing.Point(76, 184);
            this.tbEkleKm.Name = "tbEkleKm";
            this.tbEkleKm.Size = new System.Drawing.Size(137, 20);
            this.tbEkleKm.TabIndex = 16;
            // 
            // tbEkleGunlukFiyat
            // 
            this.tbEkleGunlukFiyat.Location = new System.Drawing.Point(76, 158);
            this.tbEkleGunlukFiyat.Name = "tbEkleGunlukFiyat";
            this.tbEkleGunlukFiyat.Size = new System.Drawing.Size(137, 20);
            this.tbEkleGunlukFiyat.TabIndex = 15;
            // 
            // tbEkleYili
            // 
            this.tbEkleYili.Location = new System.Drawing.Point(76, 132);
            this.tbEkleYili.Name = "tbEkleYili";
            this.tbEkleYili.Size = new System.Drawing.Size(137, 20);
            this.tbEkleYili.TabIndex = 14;
            // 
            // tbEkleRenk
            // 
            this.tbEkleRenk.Location = new System.Drawing.Point(76, 109);
            this.tbEkleRenk.Name = "tbEkleRenk";
            this.tbEkleRenk.Size = new System.Drawing.Size(137, 20);
            this.tbEkleRenk.TabIndex = 13;
            // 
            // tbEkleModel
            // 
            this.tbEkleModel.Location = new System.Drawing.Point(76, 83);
            this.tbEkleModel.Name = "tbEkleModel";
            this.tbEkleModel.Size = new System.Drawing.Size(137, 20);
            this.tbEkleModel.TabIndex = 12;
            // 
            // tbEkleMarka
            // 
            this.tbEkleMarka.Location = new System.Drawing.Point(76, 57);
            this.tbEkleMarka.Name = "tbEkleMarka";
            this.tbEkleMarka.Size = new System.Drawing.Size(137, 20);
            this.tbEkleMarka.TabIndex = 11;
            // 
            // tbEklePlaka
            // 
            this.tbEklePlaka.Location = new System.Drawing.Point(76, 31);
            this.tbEklePlaka.Name = "tbEklePlaka";
            this.tbEklePlaka.Size = new System.Drawing.Size(137, 20);
            this.tbEklePlaka.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Renk :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Plaka :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 187);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Km :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Model :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Günlük Fiyat :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Yılı :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 60);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Marka :";
            // 
            // DgwAraclar
            // 
            this.DgwAraclar.AllowUserToAddRows = false;
            this.DgwAraclar.AllowUserToDeleteRows = false;
            this.DgwAraclar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgwAraclar.Location = new System.Drawing.Point(6, 6);
            this.DgwAraclar.MultiSelect = false;
            this.DgwAraclar.Name = "DgwAraclar";
            this.DgwAraclar.ReadOnly = true;
            this.DgwAraclar.Size = new System.Drawing.Size(897, 316);
            this.DgwAraclar.TabIndex = 0;
            this.DgwAraclar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgwAraclar_CellClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.DgwMusteriler);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(909, 576);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Müşteriler";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.buttonMusteriSil);
            this.groupBox4.Location = new System.Drawing.Point(614, 328);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(288, 242);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Silme İşlemleri";
            // 
            // buttonMusteriSil
            // 
            this.buttonMusteriSil.Location = new System.Drawing.Point(26, 125);
            this.buttonMusteriSil.Name = "buttonMusteriSil";
            this.buttonMusteriSil.Size = new System.Drawing.Size(239, 23);
            this.buttonMusteriSil.TabIndex = 17;
            this.buttonMusteriSil.Text = "Seçileni Sil";
            this.buttonMusteriSil.UseVisualStyleBackColor = true;
            this.buttonMusteriSil.Click += new System.EventHandler(this.buttonMusteriSil_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.buttonGuncelleMusteri);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.tbGuncelleTelefon);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.tbGuncelleAdres);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.tbGuncelleSoyad);
            this.groupBox5.Controls.Add(this.tbGuncelleAd);
            this.groupBox5.Controls.Add(this.tbGuncelleTcKimlik);
            this.groupBox5.Location = new System.Drawing.Point(311, 328);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(288, 242);
            this.groupBox5.TabIndex = 22;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Güncelleme İşlemleri";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(27, 112);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 13);
            this.label23.TabIndex = 22;
            this.label23.Text = "Adres :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 34);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 13);
            this.label25.TabIndex = 19;
            this.label25.Text = "Kimlik No :";
            // 
            // buttonGuncelleMusteri
            // 
            this.buttonGuncelleMusteri.Location = new System.Drawing.Point(76, 213);
            this.buttonGuncelleMusteri.Name = "buttonGuncelleMusteri";
            this.buttonGuncelleMusteri.Size = new System.Drawing.Size(137, 23);
            this.buttonGuncelleMusteri.TabIndex = 17;
            this.buttonGuncelleMusteri.Text = "Güncelle";
            this.buttonGuncelleMusteri.UseVisualStyleBackColor = true;
            this.buttonGuncelleMusteri.Click += new System.EventHandler(this.buttonGuncelleMusteri_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(27, 86);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(43, 13);
            this.label30.TabIndex = 20;
            this.label30.Text = "Soyad :";
            // 
            // tbGuncelleTelefon
            // 
            this.tbGuncelleTelefon.Location = new System.Drawing.Point(76, 132);
            this.tbGuncelleTelefon.Name = "tbGuncelleTelefon";
            this.tbGuncelleTelefon.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleTelefon.TabIndex = 14;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(18, 135);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(49, 13);
            this.label32.TabIndex = 18;
            this.label32.Text = "Telefon :";
            // 
            // tbGuncelleAdres
            // 
            this.tbGuncelleAdres.Location = new System.Drawing.Point(76, 109);
            this.tbGuncelleAdres.Name = "tbGuncelleAdres";
            this.tbGuncelleAdres.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleAdres.TabIndex = 13;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(41, 60);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(26, 13);
            this.label35.TabIndex = 21;
            this.label35.Text = "Ad :";
            // 
            // tbGuncelleSoyad
            // 
            this.tbGuncelleSoyad.Location = new System.Drawing.Point(76, 83);
            this.tbGuncelleSoyad.Name = "tbGuncelleSoyad";
            this.tbGuncelleSoyad.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleSoyad.TabIndex = 12;
            // 
            // tbGuncelleAd
            // 
            this.tbGuncelleAd.Location = new System.Drawing.Point(76, 57);
            this.tbGuncelleAd.Name = "tbGuncelleAd";
            this.tbGuncelleAd.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleAd.TabIndex = 11;
            // 
            // tbGuncelleTcKimlik
            // 
            this.tbGuncelleTcKimlik.Location = new System.Drawing.Point(76, 31);
            this.tbGuncelleTcKimlik.Name = "tbGuncelleTcKimlik";
            this.tbGuncelleTcKimlik.Size = new System.Drawing.Size(137, 20);
            this.tbGuncelleTcKimlik.TabIndex = 10;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.buttonMusteriEkle);
            this.groupBox6.Controls.Add(this.tbEkleTelefon);
            this.groupBox6.Controls.Add(this.tbEkleAdres);
            this.groupBox6.Controls.Add(this.tbEkleSoyad);
            this.groupBox6.Controls.Add(this.tbEkleAd);
            this.groupBox6.Controls.Add(this.tbEkleTcKimlik);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Location = new System.Drawing.Point(6, 328);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(288, 242);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Ekleme İşlemleri";
            // 
            // buttonMusteriEkle
            // 
            this.buttonMusteriEkle.Location = new System.Drawing.Point(76, 213);
            this.buttonMusteriEkle.Name = "buttonMusteriEkle";
            this.buttonMusteriEkle.Size = new System.Drawing.Size(137, 23);
            this.buttonMusteriEkle.TabIndex = 17;
            this.buttonMusteriEkle.Text = "Ekle";
            this.buttonMusteriEkle.UseVisualStyleBackColor = true;
            this.buttonMusteriEkle.Click += new System.EventHandler(this.buttonMusteriEkle_Click);
            // 
            // tbEkleTelefon
            // 
            this.tbEkleTelefon.Location = new System.Drawing.Point(76, 132);
            this.tbEkleTelefon.Name = "tbEkleTelefon";
            this.tbEkleTelefon.Size = new System.Drawing.Size(137, 20);
            this.tbEkleTelefon.TabIndex = 14;
            // 
            // tbEkleAdres
            // 
            this.tbEkleAdres.Location = new System.Drawing.Point(76, 109);
            this.tbEkleAdres.Name = "tbEkleAdres";
            this.tbEkleAdres.Size = new System.Drawing.Size(137, 20);
            this.tbEkleAdres.TabIndex = 13;
            // 
            // tbEkleSoyad
            // 
            this.tbEkleSoyad.Location = new System.Drawing.Point(76, 83);
            this.tbEkleSoyad.Name = "tbEkleSoyad";
            this.tbEkleSoyad.Size = new System.Drawing.Size(137, 20);
            this.tbEkleSoyad.TabIndex = 12;
            // 
            // tbEkleAd
            // 
            this.tbEkleAd.Location = new System.Drawing.Point(76, 57);
            this.tbEkleAd.Name = "tbEkleAd";
            this.tbEkleAd.Size = new System.Drawing.Size(137, 20);
            this.tbEkleAd.TabIndex = 11;
            // 
            // tbEkleTcKimlik
            // 
            this.tbEkleTcKimlik.Location = new System.Drawing.Point(76, 31);
            this.tbEkleTcKimlik.Name = "tbEkleTcKimlik";
            this.tbEkleTcKimlik.Size = new System.Drawing.Size(137, 20);
            this.tbEkleTcKimlik.TabIndex = 10;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(20, 112);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 13);
            this.label28.TabIndex = 9;
            this.label28.Text = "Adres :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 34);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(57, 13);
            this.label29.TabIndex = 4;
            this.label29.Text = "Kimlik No :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(20, 86);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(43, 13);
            this.label31.TabIndex = 6;
            this.label31.Text = "Soyad :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(11, 135);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(49, 13);
            this.label33.TabIndex = 3;
            this.label33.Text = "Telefon :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(34, 60);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(26, 13);
            this.label34.TabIndex = 7;
            this.label34.Text = "Ad :";
            // 
            // DgwMusteriler
            // 
            this.DgwMusteriler.AllowUserToAddRows = false;
            this.DgwMusteriler.AllowUserToDeleteRows = false;
            this.DgwMusteriler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgwMusteriler.Location = new System.Drawing.Point(6, 6);
            this.DgwMusteriler.MultiSelect = false;
            this.DgwMusteriler.Name = "DgwMusteriler";
            this.DgwMusteriler.ReadOnly = true;
            this.DgwMusteriler.Size = new System.Drawing.Size(897, 316);
            this.DgwMusteriler.TabIndex = 20;
            this.DgwMusteriler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgwMusteriler_CellClick);
            // 
            // OtomasyonForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 618);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "OtomasyonForm";
            this.Text = "Otomasyon";
            this.Load += new System.EventHandler(this.OtomasyonForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwKiralamaAraclar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DgwKiralamaMusteriler)).EndInit();
            this.Tab2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwAktifislemler)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgwGecmisislemler)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwAraclar)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgwMusteriler)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage Tab2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTutar;
        private System.Windows.Forms.DateTimePicker DtpTeslimEdilecek;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView DgwKiralamaAraclar;
        private System.Windows.Forms.DataGridView DgwKiralamaMusteriler;
        private System.Windows.Forms.Button btIslemiOnayla;
        private System.Windows.Forms.DataGridView DgwAraclar;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbEkleKm;
        private System.Windows.Forms.TextBox tbEkleGunlukFiyat;
        private System.Windows.Forms.TextBox tbEkleYili;
        private System.Windows.Forms.TextBox tbEkleRenk;
        private System.Windows.Forms.TextBox tbEkleModel;
        private System.Windows.Forms.TextBox tbEkleMarka;
        private System.Windows.Forms.TextBox tbEklePlaka;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonAracEkle;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonAracGuncelle;
        private System.Windows.Forms.TextBox tbGuncelleKm;
        private System.Windows.Forms.TextBox tbGuncelleGunlukFiyat;
        private System.Windows.Forms.TextBox tbGuncelleYili;
        private System.Windows.Forms.TextBox tbGuncelleRenk;
        private System.Windows.Forms.TextBox tbGuncelleModel;
        private System.Windows.Forms.TextBox tbGuncelleMarka;
        private System.Windows.Forms.TextBox tbGuncellePlaka;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button ButtonAraciSil;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button ButtonPlakayaGoreSil;
        private System.Windows.Forms.TextBox tbSilPlaka;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonMusteriSil;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonMusteriEkle;
        private System.Windows.Forms.TextBox tbEkleTelefon;
        private System.Windows.Forms.TextBox tbEkleAdres;
        private System.Windows.Forms.TextBox tbEkleSoyad;
        private System.Windows.Forms.TextBox tbEkleAd;
        private System.Windows.Forms.TextBox tbEkleTcKimlik;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.DataGridView DgwMusteriler;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button buttonGuncelleMusteri;
        private System.Windows.Forms.TextBox tbGuncelleTelefon;
        private System.Windows.Forms.TextBox tbGuncelleAdres;
        private System.Windows.Forms.TextBox tbGuncelleSoyad;
        private System.Windows.Forms.TextBox tbGuncelleAd;
        private System.Windows.Forms.TextBox tbGuncelleTcKimlik;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DateTimePicker DtpTeslimAlınacak;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DataGridView DgwAktifislemler;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button buttonislemTamamlandı;
        private System.Windows.Forms.Button buttonAktifiptal;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button buttonAiGuncelle;
        private System.Windows.Forms.TextBox tbAktifTutar;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.DateTimePicker DtpAiTeslimEdilecek;
        private System.Windows.Forms.DateTimePicker DtpAiTeslimAlınacak;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button buttonKaydiSil;
        private System.Windows.Forms.DataGridView DgwGecmisislemler;
    }
}

